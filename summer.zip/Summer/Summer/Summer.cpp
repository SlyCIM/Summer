#include "stdafx.h"
#include "Input_Output.h"
#include "lexical_unit.h"
#include "syntax_unit.h"
#include "transliter_unit.h"

int main()
{
	lexem_array lexem_arr;
	string in_str = input();
	
	try
	{
		transliter(in_str, lexem_arr);
		lexic_unit(lexem_arr);
		syntax_unit(lexem_arr);
		output(accept);
	}
	
	catch (exception & message)
	{
		cerr << message.what();
		output(reject);
		system("PAUSE");
	}
	return 0;
}

